
function validateForm() {
	if(form["RegForm"]["password"].value!=form["RegForm"]["confirmPassword"].value)
		window.alert("password does not match");
}
