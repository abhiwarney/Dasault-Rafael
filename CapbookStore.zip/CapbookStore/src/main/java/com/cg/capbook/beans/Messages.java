package com.cg.capbook.beans;
import java.time.LocalDateTime;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Messages{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int message_Id;
	private String text;
	private LocalDateTime date11=LocalDateTime.now();
	@ManyToOne
	private Chat chat;
	
	public Messages() {}
	
	public Messages(String text, LocalDateTime date11, Chat chat) {
		super();
		this.text = text;
		this.date11 = date11;
		this.chat = chat;
	}

	public Messages(String text, LocalDateTime date11) {
		super();
		this.text = text;
		this.date11 = date11;
	}
	public int getMessage_Id() {
		return message_Id;
	}

	public void setMessage_Id(int message_Id) {
		this.message_Id = message_Id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDateTime getdate11() {
		return date11;
	}

	public void setdate(LocalDateTime date11) {
		this.date11 = date11;
	}

	public Chat getChat() {
		return chat;
	}

	public void setChat(Chat chat) {
		this.chat = chat;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((chat == null) ? 0 : chat.hashCode());
		result = prime * result + ((date11 == null) ? 0 : date11.hashCode());
		result = prime * result + message_Id;
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Messages other = (Messages) obj;
		if (chat == null) {
			if (other.chat != null)
				return false;
		} else if (!chat.equals(other.chat))
			return false;
		if (date11 == null) {
			if (other.date11 != null)
				return false;
		} else if (!date11.equals(other.date11))
			return false;
		if (message_Id != other.message_Id)
			return false;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Messages [message_Id=" + message_Id + ", text=" + text + ", date11=" + date11 + "]";
	}


	
}
