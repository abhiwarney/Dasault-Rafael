package com.cg.capbook.beans;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Chat {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int chatId;
	private int recieverId;
	@OneToMany(mappedBy="chat",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,Messages>messages;
	@ManyToOne
	private UserProfile user;

	public Chat() {}

	public Chat(int recieverId, Map<Integer, Messages> messages, UserProfile user) {
		super();
		this.recieverId = recieverId;
		this.messages = messages;
		this.user = user;
	}

	public int getChatId() {
		return chatId;
	}

	public void setChatId(int chatId) {
		this.chatId = chatId;
	}

	public int getRecieverId() {
		return recieverId;
	}

	public void setRecieverId(int recieverId) {
		this.recieverId = recieverId;
	}

	public Map<Integer, Messages> getMessages() {
		return messages;
	}

	public void setMessages(Map<Integer, Messages> messages) {
		this.messages = messages;
	}

	public UserProfile getUser() {
		return user;
	}

	public void setUser(UserProfile user) {
		this.user = user;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + chatId;
		result = prime * result + ((messages == null) ? 0 : messages.hashCode());
		result = prime * result + recieverId;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Chat other = (Chat) obj;
		if (chatId != other.chatId)
			return false;
		if (messages == null) {
			if (other.messages != null)
				return false;
		} else if (!messages.equals(other.messages))
			return false;
		if (recieverId != other.recieverId)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Chat [chatId=" + chatId + ", recieverId=" + recieverId + ", messages=" + messages + "]";
	}

	

}
