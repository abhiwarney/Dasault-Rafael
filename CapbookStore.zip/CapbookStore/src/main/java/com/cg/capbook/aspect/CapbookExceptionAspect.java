package com.cg.capbook.aspect;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.exceptions.InvalidCurrentPasswordException;
import com.cg.capbook.exceptions.InvalidEmailException;
import com.cg.capbook.exceptions.InvalidPasswordException;
import com.cg.capbook.exceptions.InvalidSecurityAnswerException;
import com.cg.capbook.exceptions.UserAlreadyExistException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
@ControllerAdvice
public class CapbookExceptionAspect {
	@ExceptionHandler(UserProfileNotFoundException.class) 
	public ModelAndView handleUserProfileNotFoundException(Exception e) { 
		return new ModelAndView("errorPage", "errorMessage", e.getMessage()); 
	}
	@ExceptionHandler(InvalidSecurityAnswerException.class) 
	public ModelAndView handleInvalidSecurityAnswerException(Exception e) { 
		return new ModelAndView("forgotPasswordPage", "errorMessage", e.getMessage()); 
	}
	@ExceptionHandler(InvalidCurrentPasswordException.class) 
	public ModelAndView handleInvalidCurrentPasswordException(Exception e) { 
		return new ModelAndView("changePasswordPage", "errorMessage", e.getMessage()); 
	}
	@ExceptionHandler(InvalidEmailException.class) 
	public ModelAndView InvalidEmailException(Exception e) { 
		return new ModelAndView("indexPage", "errorMessage", e.getMessage()); 
	}
	@ExceptionHandler(UserAlreadyExistException.class) 
	public ModelAndView handleUserAlreadyExistException(Exception e) { 
		return new ModelAndView("indexPage", "errorMessage", e.getMessage()); 
	}
	@ExceptionHandler(InvalidPasswordException.class) 
	public ModelAndView handleInvalidPasswordException(Exception e) { 
		return new ModelAndView("indexPage", "errorMessage", e.getMessage()); 
	}
}
