package com.cg.capbook.exceptions;

public class CommentDetailsNotFoundException extends RuntimeException{

	public CommentDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommentDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CommentDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CommentDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CommentDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
