package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Comments;

public interface CommentDao extends JpaRepository<Comments, Integer>{
@Query("from Comments c where c.postedBy=:user and c.post.postId=:post")
Comments getComments(@Param("user")int postedBy,@Param("post") int postId);
}
