package com.cg.capbook.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.Comments;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.services.LoginService;
import com.cg.capbook.services.PasswordServices;
import com.cg.capbook.services.PostServices;
import com.cg.capbook.services.UserProfileServices;

@Controller
@SessionAttributes("user")
public class CapbookServiceController {

	@Autowired
	UserProfileServices userProfileServices;
	@Autowired
	PasswordServices passwordServices;
	@Autowired
	LoginService loginService;
	@Autowired
	FileUploadController fileUploadController;
	@Autowired
	PostServices postServices;
	
	@RequestMapping("/registerUser")
	public ModelAndView registerUser(@ModelAttribute UserProfile user) {
		UserProfile user1=userProfileServices.acceptUserProfileDetails(user);
		return new ModelAndView("dashboard","user",user1);
	}
	@RequestMapping("/login")
	public ModelAndView loginUser(@RequestParam String email,String password) {
		return new ModelAndView("dashboard","user",	loginService.loginUser(email, password));
	}
	@RequestMapping("/forgotPassword")
	public ModelAndView forgotPassword(@RequestParam String email,String securityQuestion,String securityAnswer) {
		String password=passwordServices.forgotUserPassword(email, securityQuestion, securityAnswer);
		return new ModelAndView("forgotPasswordPage","password",password);
	}
	@RequestMapping("/changePassword")
	public ModelAndView changePassword(@SessionAttribute("user") UserProfile user,@RequestParam String newPassword,String currentPassword) {
		passwordServices.changeUserPassword(user.getUserId(), newPassword, currentPassword);
		return new ModelAndView("dashboard","user",userProfileServices.getUserProfileDetails(user.getUserId()));
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(SessionStatus status) {
		status.setComplete();
		return "indexPage";
	}
	
	@RequestMapping(value="/commentPost")
	public ModelAndView commentPost(@SessionAttribute("user") UserProfile user,@RequestParam int postId,int postedBy,String commentBody) {
		postServices.commentPost(postId, commentBody, postedBy);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "user", user);
	}
	@RequestMapping(value="/likePost")
	public ModelAndView likePost(@SessionAttribute("user") UserProfile user,@RequestParam int postId,int likedDislikeBy) {
		postServices.likePost(user.getUserId(), postId, likedDislikeBy);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "user", user);
	}
	@RequestMapping(value="/dislikePost")
	public ModelAndView dislikePost(@SessionAttribute("user") UserProfile user,@RequestParam int postId,int likedDislikeBy) {
		postServices.dislikePost(user.getUserId(), postId, likedDislikeBy);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "user", user);
	}
	@RequestMapping(value="/deleteComment")
	public ModelAndView deleteComment(@SessionAttribute("user") UserProfile user,@RequestParam int postId,int deletedBy,int commentId) {
		postServices.deleteComment(postId, deletedBy,commentId);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "user", user);
	}
}

