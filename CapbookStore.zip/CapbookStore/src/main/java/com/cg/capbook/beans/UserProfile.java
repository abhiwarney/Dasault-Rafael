package com.cg.capbook.beans;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
@Entity
public class UserProfile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int userId;
	@NotEmpty
	private String firstName;
	@NotEmpty
	private String lastName;
	@NotEmpty
	private String gender;
	@NotEmpty
	private String mobileNo;
	@NotEmpty
	@Email
	private String emailId;
	@NotEmpty
	private String password;
	private String dob;
	private String securityQuestion;
	private String securityAnswer;
	private String profileImgUrl;
	public String getProfileImgUrl() {
		return profileImgUrl;
	}

	public void setProfileImgUrl(String profileImgUrl) {
		this.profileImgUrl = profileImgUrl;
	}

	@OneToOne(mappedBy="user",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	private Address address;
	@OneToMany(mappedBy="recieverId",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,FriendRequest>friendRequests;
	@OneToMany(mappedBy="user",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@ElementCollection
	private List<FriendList>friendList;
	@OneToMany(mappedBy="user",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer, Chat>chats;
	@OneToMany(mappedBy="user",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer, Post>post;
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer, Forum>forums;
	public UserProfile() {}

	public UserProfile(@NotEmpty String firstName, @NotEmpty String lastName, @NotEmpty String gender,
			@NotEmpty String mobileNo, @NotEmpty @Email String emailId, @NotEmpty String password, String dob,
			String securityQuestion, String securityAnswer, String profileImgUrl, Address address,
			Map<Integer, FriendRequest> friendRequests, List<FriendList> friendList, Map<Integer, Chat> chats,
			Map<Integer, Post> post, Map<Integer, Forum> forums) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
		this.profileImgUrl = profileImgUrl;
		this.address = address;
		this.friendRequests = friendRequests;
		this.friendList = friendList;
		this.chats = chats;
		this.post = post;
		this.forums = forums;
	}

	public UserProfile(@NotEmpty String firstName, @NotEmpty String lastName, @NotEmpty String gender,
			@NotEmpty String mobileNo, @NotEmpty @Email String emailId, @NotEmpty String password, String dob,
			String securityQuestion, String securityAnswer) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
		this.dob = dob;
		this.securityQuestion = securityQuestion;
		this.securityAnswer = securityAnswer;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getSecurityAnswer() {
		return securityAnswer;
	}

	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Map<Integer, FriendRequest> getFriendRequests() {
		return friendRequests;
	}

	public void setFriendRequests(Map<Integer, FriendRequest> friendRequests) {
		this.friendRequests = friendRequests;
	}

	public List<FriendList> getFriendList() {
		return friendList;
	}

	public void setFriendList(List<FriendList> friendList) {
		this.friendList = friendList;
	}

	public Map<Integer, Chat> getChats() {
		return chats;
	}

	public void setChats(Map<Integer, Chat> chats) {
		this.chats = chats;
	}

	public Map<Integer, Post> getPost() {
		return post;
	}

	public void setPost(Map<Integer, Post> post) {
		this.post = post;
	}

	public Map<Integer, Forum> getForums() {
		return forums;
	}

	public void setForums(Map<Integer, Forum> forums) {
		this.forums = forums;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((chats == null) ? 0 : chats.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((forums == null) ? 0 : forums.hashCode());
		result = prime * result + ((friendList == null) ? 0 : friendList.hashCode());
		result = prime * result + ((friendRequests == null) ? 0 : friendRequests.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		result = prime * result + ((profileImgUrl == null) ? 0 : profileImgUrl.hashCode());
		result = prime * result + ((securityAnswer == null) ? 0 : securityAnswer.hashCode());
		result = prime * result + ((securityQuestion == null) ? 0 : securityQuestion.hashCode());
		result = prime * result + userId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserProfile other = (UserProfile) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (chats == null) {
			if (other.chats != null)
				return false;
		} else if (!chats.equals(other.chats))
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (forums == null) {
			if (other.forums != null)
				return false;
		} else if (!forums.equals(other.forums))
			return false;
		if (friendList == null) {
			if (other.friendList != null)
				return false;
		} else if (!friendList.equals(other.friendList))
			return false;
		if (friendRequests == null) {
			if (other.friendRequests != null)
				return false;
		} else if (!friendRequests.equals(other.friendRequests))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (post == null) {
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		if (profileImgUrl == null) {
			if (other.profileImgUrl != null)
				return false;
		} else if (!profileImgUrl.equals(other.profileImgUrl))
			return false;
		if (securityAnswer == null) {
			if (other.securityAnswer != null)
				return false;
		} else if (!securityAnswer.equals(other.securityAnswer))
			return false;
		if (securityQuestion == null) {
			if (other.securityQuestion != null)
				return false;
		} else if (!securityQuestion.equals(other.securityQuestion))
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UserProfile [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", mobileNo=" + mobileNo + ", emailId=" + emailId + ", password=" + password + ", dob=" + dob
				+ ", securityQuestion=" + securityQuestion + ", securityAnswer=" + securityAnswer + ", profileImgUrl="
				+ profileImgUrl + ", address=" + address + ", friendRequests=" + friendRequests + ", friendList="
				+ friendList + ", chats=" + chats + ", post=" + post + ", forums=" + forums + "]";
	}


}
