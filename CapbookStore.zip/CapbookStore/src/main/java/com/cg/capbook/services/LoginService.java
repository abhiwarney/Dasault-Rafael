package com.cg.capbook.services;

import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.InvalidEmailException;
import com.cg.capbook.exceptions.InvalidPasswordException;

public interface LoginService {
UserProfile loginUser(String email,String password)throws InvalidEmailException,InvalidPasswordException;
}
