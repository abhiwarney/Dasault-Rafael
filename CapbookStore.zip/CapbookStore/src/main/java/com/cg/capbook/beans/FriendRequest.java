package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FriendRequest {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int requestId;
	private int senderId;
	private int recieverId;
	private String status="pending";
	public FriendRequest() {}
	public FriendRequest(int senderId, int recieverId, String status) {
		super();
		this.senderId = senderId;
		this.recieverId = recieverId;
		this.status = status;
	}
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public int getSenderId() {
		return senderId;
	}
	public void setSenderId(int senderId) {
		this.senderId = senderId;
	}
	public int getRecieverId() {
		return recieverId;
	}
	public void setRecieverId(int recieverId) {
		this.recieverId = recieverId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + recieverId;
		result = prime * result + requestId;
		result = prime * result + senderId;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FriendRequest other = (FriendRequest) obj;
		if (recieverId != other.recieverId)
			return false;
		if (requestId != other.requestId)
			return false;
		if (senderId != other.senderId)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "FriendRequest [requestId=" + requestId + ", senderId=" + senderId + ", recieverId=" + recieverId + "]";
	}
	
	
}
