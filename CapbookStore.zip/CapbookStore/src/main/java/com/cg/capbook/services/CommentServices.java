package com.cg.capbook.services;

import java.util.List;

import com.cg.capbook.beans.Comments;

public interface CommentServices {
	Comments saveComment(Comments comment);
	Comments getCommentDetails(int postedBy,int postId);
	List<Comments> getAllComments(int postId);
	Comments updateComment(Comments comment);
	Comments getCommentDetailsById(int commentId);
	boolean deleteComment(int deletedBy, int postId, int commentId);
}
