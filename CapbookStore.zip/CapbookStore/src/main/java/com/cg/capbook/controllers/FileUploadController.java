package com.cg.capbook.controllers;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.capbook.beans.Image;
import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.FileStorageException;
import com.cg.capbook.services.ImageServices;
import com.cg.capbook.services.PostServices;
import com.cg.capbook.services.StorageService;
import com.cg.capbook.services.UserProfileServices;
@Controller
@SessionAttributes("user")
public class FileUploadController {
	private final StorageService storageService;
	private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);
	@Autowired
	ImageServices imageServices;
	@Autowired
	PostServices postServices;
	@Autowired
	UserProfileServices userProfileServices;
	@Autowired
	public FileUploadController(StorageService storageService) {
		this.storageService = storageService;
	}

	@RequestMapping("/uploadProfilePic")
	public ModelAndView uploadProfileFile(@SessionAttribute("user") UserProfile user,@RequestParam("file") MultipartFile file) throws FileStorageException {
		String fileName = storageService.store(file);
		String imageURL = ServletUriComponentsBuilder.fromCurrentContextPath()
				.path("/downloadFile/")
				.path(fileName)
				.toUriString();
		user.setProfileImgUrl(imageURL);
		userProfileServices.updateUserProfileDetails(user);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "user", user);

	}
	@RequestMapping("/uploadPost")
	public ModelAndView savePost(@SessionAttribute("user") UserProfile user,@RequestParam String statusBody,@RequestParam("file") MultipartFile file) throws FileStorageException {
		Post post = new Post(statusBody,user);
		post=postServices.savePost(post);
		String albumName="default";

		Image image=uploadFile(file, albumName);
		/*
		 * List<MultipartFile>imageList=Arrays.asList(files); for (MultipartFile file :
		 * imageList) { Image image = uploadFile(file,albumName); image.setPost(post); }
		 */ 
		image.setPost(post);
		image=imageServices.saveImage(image);
		post=postServices.getPostDetails(post.getPostId());
		Map<Integer, Image>images = new HashMap<Integer,Image>();
		images.put(image.getImageId(), image);
		post.setImages(images);
		System.out.println(post);
		user=userProfileServices.getUserProfileDetails(user.getUserId());
		return new ModelAndView("dashboard", "post", post);
	}


	@RequestMapping("/uploadFile") 
	public Image uploadFile(@RequestParam("file")MultipartFile file,String albumName)throws FileStorageException {
		String fileName =storageService.store(file); 
		String imageURL =ServletUriComponentsBuilder.fromCurrentContextPath()
				.path("/downloadFile/")
				.path(fileName) 
				.toUriString(); 
		Image image =new Image(LocalDateTime.now(),fileName, file.getContentType(), file.getSize(), albumName, imageURL);
		return image;
	}



	@GetMapping("/downloadFile/{fileName:.+}")
	public ResponseEntity<Resource>downloadFile(@PathVariable String fileName, HttpServletRequest request) {
		// Load file as Resource 
		Resource resource =storageService.loadFileAsResource(fileName);

		// Try to determine file's content type
		String contentType = null; 
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath()); 
		} 
		catch (IOException ex) { logger.info("Could not determine file type."); }

		// Fallback to the default content type if type could not be determined
		if(contentType == null) { contentType = "application/octet-stream"; }

		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" +
						resource.getFilename() + "\"") .body(resource); }

}

