package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Likes;
import com.cg.capbook.daoservices.LikeDao;
@Component("likeServices")
public class LikeServicesImpl implements LikeServices {
	@Autowired 
	LikeDao likeDao;
	@Override
	public Likes saveLike(Likes like) {
		return likeDao.save(like);
	}

	@Override
	public Likes updateLike(Likes like) {
		return likeDao.save(like);
	}

	@Override
	public Likes getLike(int userId, int postId) {
		return  likeDao.getLikes(userId, postId);
	}

	@Override
	public boolean deleteLike(int userId,int postId) {
		likeDao.delete(getLike(userId, postId));
		return  true;
	}

	@Override
	public int countLikes(int postId) {
		return likeDao.countLikes(postId);
	}

	@Override
	public int countDislikes(int postId) {
		return likeDao.countDisLikes(postId);
	}

}
