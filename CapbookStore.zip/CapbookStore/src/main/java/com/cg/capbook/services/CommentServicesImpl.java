package com.cg.capbook.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Comments;
import com.cg.capbook.daoservices.CommentDao;
import com.cg.capbook.exceptions.CommentDetailsNotFoundException;

@Component("commentServicesImpl")
public class CommentServicesImpl implements CommentServices{
	@Autowired 
	CommentDao commentDao;
	@Override
	public Comments saveComment(Comments comment) {
		return commentDao.save(comment);
	}

	@Override
	public Comments updateComment(Comments comment) {
		return commentDao.save(comment);
	}
	
	@Override
	public boolean deleteComment(int deletedBy, int postId,int commentId) {
		if(getCommentDetailsById(commentId).getPostedBy()==deletedBy)
		commentDao.delete(getCommentDetailsById(commentId));
		return true;
	}

	@Override
	public Comments getCommentDetails(int postedBy, int postId) {
		return commentDao.getComments(postedBy, postId);
	}
	@Override
	public Comments getCommentDetailsById(int commentId) {
		return commentDao.findById(commentId).orElseThrow(()->new CommentDetailsNotFoundException("Comment Details Not Found Exception"));
	}

	@Override
	public List<Comments> getAllComments(int postId) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
