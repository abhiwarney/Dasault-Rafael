package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.Likes;

public interface LikeDao extends JpaRepository<Likes, Integer> {
	@Query("from Likes l where l.likedDislikeBy=:user and l.post.postId=:post")
	Likes getLikes(@Param("user")int userId,@Param("post")int postId);
	@Query("select count(*) from Likes l where l.type='like' and l.post.postId=:post")
	int countLikes(@Param("post")int postId);
	@Query("select count(*) from Likes l where l.type='dislike' and l.post.postId=:post")
	int countDisLikes(@Param("post")int postId);
}
