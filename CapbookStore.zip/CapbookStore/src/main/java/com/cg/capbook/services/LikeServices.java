package com.cg.capbook.services;

import com.cg.capbook.beans.Likes;

public interface LikeServices {
	Likes saveLike(Likes like);
	Likes updateLike(Likes like);
	Likes getLike(int userId,int postId);
	boolean deleteLike(int userId,int postId);
	int countLikes(int postId);
	int countDislikes(int postId);
}
