package com.cg.capbook.services;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Comments;
import com.cg.capbook.beans.Likes;
import com.cg.capbook.beans.Post;
import com.cg.capbook.daoservices.PostDao;
import com.cg.capbook.exceptions.PostNotFoundException;
@Component("postServices")
public class PostServicesImpl implements PostServices{
	@Autowired
	PostDao postDao;
	@Autowired
	UserProfileServices userProfileServices;
	@Autowired
	LikeServices likeServices;
	@Autowired
	CommentServices commentServices;
	@Override
	public Post savePost(Post post) {

		return postDao.save(post);

	}

	@Override
	public Post updatePost(int userId, Post post) {
		userProfileServices.getUserProfileDetails(userId);
		return postDao.save(post);
	}

	@Override
	public boolean deletePost(int postId) {
		postDao.deleteById(postId);
		return true;
	}

	@Override
	public boolean likePost(int userId,int postId, int likedDislikeBy) {
		Post post = getPostDetails(postId);
		if(likeServices.getLike(likedDislikeBy, postId)==null) {
			likeServices.saveLike(new Likes(likedDislikeBy,"like", LocalDateTime.now(), post));
			post.setLikeCount(likeServices.countLikes(postId));
			updatePost(userId, post);
		}
		else if(likeServices.getLike(likedDislikeBy, postId).getType().equalsIgnoreCase("like")){
			likeServices.deleteLike(likedDislikeBy, postId);
			post.setLikeCount(likeServices.countLikes(postId));
			updatePost(userId, post);
		}
		else if(likeServices.getLike(likedDislikeBy, postId).getType().equalsIgnoreCase("dislike")){
			Likes like= likeServices.getLike(likedDislikeBy, postId);
			like.setType("like");
			like.setDateOfLike(LocalDateTime.now());
			likeServices.saveLike(like);
			post.setLikeCount(likeServices.countLikes(postId));
			post.setDislikeCount(likeServices.countDislikes(postId));
			updatePost(userId, post);
		}
		return false;
	}

	@Override
	public boolean dislikePost(int userId,int postId, int likedDislikeBy) {
		Post post = getPostDetails(postId);
		if(likeServices.getLike(likedDislikeBy, postId)==null) {
			likeServices.saveLike(new Likes(likedDislikeBy,"dislike", LocalDateTime.now(), post));
			post.setDislikeCount(likeServices.countDislikes(postId));
			updatePost(userId, post);
		}
		else if(likeServices.getLike(likedDislikeBy, postId).getType().equalsIgnoreCase("dislike")){
			likeServices.deleteLike(likedDislikeBy, postId);
			post.setDislikeCount(likeServices.countDislikes(postId));
			updatePost(userId, post);
		}
		else if(likeServices.getLike(likedDislikeBy, postId).getType().equalsIgnoreCase("like")){
			Likes like= likeServices.getLike(likedDislikeBy, postId);
			like.setType("dislike");
			like.setDateOfLike(LocalDateTime.now());
			likeServices.updateLike(like);
			post.setLikeCount(likeServices.countLikes(postId));
			post.setDislikeCount(likeServices.countDislikes(postId));
			updatePost(userId, post);
		}
		return false;
	}

	@Override
	public Comments commentPost(int postId, String commentBody, int postedBy) {
		Post post = getPostDetails(postId);
		Comments comment=commentServices.saveComment(new Comments(commentBody, postedBy, LocalDateTime.now(), 0, 0, post));
		updatePost(post.getUser().getUserId(), post);
		return comment;
	}

	@Override
	public Post getPostDetails(int postId)throws PostNotFoundException {
		return postDao.findById(postId).orElseThrow(()->new PostNotFoundException("Post Not Found"));
	}

	@Override
	public boolean deleteComment(int postId, int deletedBy,int commentId) {
		commentServices.deleteComment(deletedBy,postId,commentId);
		return false;
	}

}
