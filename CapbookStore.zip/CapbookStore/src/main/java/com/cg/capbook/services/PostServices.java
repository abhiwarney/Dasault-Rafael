package com.cg.capbook.services;

import com.cg.capbook.beans.Comments;
import com.cg.capbook.beans.Post;

public interface PostServices {
	Post savePost(Post post);
	Post updatePost(int userId,Post post);
	Post getPostDetails(int postId);
	boolean deletePost(int postId);
	boolean likePost(int userId,int postId,int likedDislikeBy);
	boolean dislikePost(int userId,int postId,int likedDislikeBy);
	Comments commentPost(int postId,String commentBody,int postedBy);
	boolean deleteComment(int postId, int deletedBy, int commentId);
}
