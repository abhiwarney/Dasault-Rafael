package com.cg.capbook.daoservices;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capbook.beans.Image;
@Repository
@Transactional
public interface ImageDao extends JpaRepository<Image, Integer> {
}
