package com.cg.capbook.beans;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Comments {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int commentId;
	private String commentBody;
	private int postedBy;
	private LocalDateTime dateOfPosting=LocalDateTime.now();
	private int likeCount=0;
	private int dislikeCount=0;
	@ManyToOne
	private Post post;
	
	public Comments() {}
	
	public Comments(String commentBody, int postedBy, LocalDateTime dateOfPosting, int likeCount, int dislikeCount,
			Post post) {
		super();
		this.commentBody = commentBody;
		this.postedBy = postedBy;
		this.dateOfPosting = dateOfPosting;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
		this.post = post;
	}

	public Comments(String commentBody, int postedBy, LocalDateTime dateOfPosting, int likeCount, int dislikeCount) {
		super();
		this.commentBody = commentBody;
		this.postedBy = postedBy;
		this.dateOfPosting = dateOfPosting;
		this.likeCount = likeCount;
		this.dislikeCount = dislikeCount;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getCommentBody() {
		return commentBody;
	}

	public void setCommentBody(String commentBody) {
		this.commentBody = commentBody;
	}

	public int getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(int postedBy) {
		this.postedBy = postedBy;
	}

	public LocalDateTime getDateOfPosting() {
		return dateOfPosting;
	}

	public void setDateOfPosting(LocalDateTime dateOfPosting) {
		this.dateOfPosting = dateOfPosting;
	}

	public int getLikeCount() {
		return likeCount;
	}

	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

	public int getDislikeCount() {
		return dislikeCount;
	}

	public void setDislikeCount(int dislikeCount) {
		this.dislikeCount = dislikeCount;
	}

	public Post getpost() {
		return post;
	}

	public void setpost(Post post) {
		this.post = post;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((commentBody == null) ? 0 : commentBody.hashCode());
		result = prime * result + commentId;
		result = prime * result + ((dateOfPosting == null) ? 0 : dateOfPosting.hashCode());
		result = prime * result + dislikeCount;
		result = prime * result + likeCount;
		result = prime * result + postedBy;
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Comments other = (Comments) obj;
		if (commentBody == null) {
			if (other.commentBody != null)
				return false;
		} else if (!commentBody.equals(other.commentBody))
			return false;
		if (commentId != other.commentId)
			return false;
		if (dateOfPosting == null) {
			if (other.dateOfPosting != null)
				return false;
		} else if (!dateOfPosting.equals(other.dateOfPosting))
			return false;
		if (dislikeCount != other.dislikeCount)
			return false;
		if (likeCount != other.likeCount)
			return false;
		if (postedBy != other.postedBy)
			return false;
		if (post == null) {
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Comments [commentId=" + commentId + ", commentBody=" + commentBody + ", postedBy=" + postedBy
				+ ", dateOfPosting=" + dateOfPosting + ", likeCount=" + likeCount + ", dislikeCount=" + dislikeCount
				+ "]";
	}


	
}
